﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace zachet_Rubtsova
{
    class Program
    {
        static List<Student> students = new List<Student>();
        static void Main(string[] args)
        {
            //Читаем данные из файла
            ReadStudentsFromFile("students.txt");

            //выводим список студентов
            Console.WriteLine("Список студентов:");
            foreach (var student in students.OrderByDescending(s=>s.FullName))
            {
                Console.WriteLine($"Индефикатор: {student.Id}, Имя:{student.FullName}");
            }
            //Ввод номера максимального балла
            Console.Write("Какой максимальный балл (1, 2, 3, ...) вы хотите найти?");
            int n = int.Parse(Console.ReadLine());

            //поиск н-ного максимального балла

            var nthMaxScore = FindNthMaxScore(n);

            //вывод результата

            if(nthMaxScore!=null)
            {
                Console.WriteLine($"Индефикатор: {nthMaxScore.Id}, Имя: {nthMaxScore.FullName}, достигнут балл: {nthMaxScore.SubjectScores.Sum(s=>s.Score)} ({string.Join("+",nthMaxScore.SubjectScores.Select(s=>s.Score))})");
            }
            else
            {
                Console.WriteLine($"В списке нет {n}-го максимального балла");
            }
            // добавление новой записи
            AddStudent();

            Console.ReadKey();

        }

        static void ReadStudentsFromFile(string fileName)
        {
            // Чтение данных из файла
            using (var reader = new StreamReader(fileName))
            {
                while (!reader.EndOfStream)
                {
                    // Чтение данных о студенте из строки файла
                    var line = reader.ReadLine();
                    var data = line.Split(';');
                    var id = int.Parse(data[0]);
                    var fullName = data[1];
                    var subjectScores = new List<SubjectScore>();
                    for (int i = 2; i < data.Length; i++)
                    {
                        var subjectScoreData = data[i].Split(',');
                        var subjectName = subjectScoreData[0];
                        var score = int.Parse(subjectScoreData[1]);
                        subjectScores.Add(new SubjectScore(subjectName, score));
                    }

                    // Создание объекта студента
                    var student = new Student(id, fullName, subjectScores);

                    // Добавление студента в список
                    students.Add(student);
                }
            }
        }

        static Student FindNthMaxScore(int n)
        {
            // Проверка на корректность ввода
            if (n <= 0)
            {
                Console.WriteLine("Введите положительное целое число.");
                return null;
            }

            // Сортировка по убыванию суммы баллов
            var sortedStudents = students.OrderByDescending(s => s.SubjectScores.Sum(ss => ss.Score)).ToList();

            // Проверка на наличие n-го максимального балла
            if (sortedStudents.Count < n)
            {
                Console.WriteLine($"В списке нет {n}-го максимального балла.");
                return null;
            }

            // Возврат студента с n-ым максимальным баллом
            return sortedStudents[n - 1];
        }

        static void AddStudent()
        {
            Console.WriteLine("Введите данные нового студента:");
            Console.Write("Идентификатор: ");
            int id = int.Parse(Console.ReadLine());
            Console.Write("ФИО: ");
            string fullName = Console.ReadLine();
            Console.Write("Количество дисциплин: ");
            int subjectCount = int.Parse(Console.ReadLine());
            var subjectScores = new List<SubjectScore>();
            for (int i = 0; i < subjectCount; i++)
            {
                Console.Write($"Название дисциплины {i + 1}: ");
                string subjectName = Console.ReadLine();
                Console.Write($"Балл по дисциплине {i + 1}: ");
                int score = int.Parse(Console.ReadLine());
                subjectScores.Add(new SubjectScore(subjectName, score));
            }

            // Создание объекта студента
            var newStudent = new Student(id, fullName, subjectScores);

            // Добавление студента в список
            students.Add(newStudent);

            Console.WriteLine("Студент добавлен.");
        }
    }
}
