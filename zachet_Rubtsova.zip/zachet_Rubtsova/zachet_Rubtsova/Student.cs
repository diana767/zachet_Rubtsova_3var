﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zachet_Rubtsova
{
     class Student
    {
        public int Id { get; set; }
        public string FullName { get; set; }
        public List<SubjectScore> SubjectScores { get; set; }
        public Student (int id, string fullName , List<SubjectScore> subjectScores)
        {
            Id = id;
            FullName = fullName;
            SubjectScores = subjectScores;
        }

    }
    
}
